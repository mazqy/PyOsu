These flag assets have been generated from [twemoji](https://twemoji.twitter.com/) 14.0.2 assets, using the [`osu_flags.sh` script](osu_flags.sh) in this directory.

Twemoji by Twitter are licenced under CC-BY 4.0.
