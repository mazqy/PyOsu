using System.Reflection;

namespace osu.Game.Resources
{
    public static class OsuResources
    {
        public static Assembly ResourceAssembly => typeof(OsuResources).Assembly;
    }
}
