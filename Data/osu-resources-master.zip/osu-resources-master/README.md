# osu!resources

[![Build status](https://ci.appveyor.com/api/projects/status/github/ppy/osu?svg=true)](https://ci.appveyor.com/project/peppy/osu-resources) [![dev chat](https://discordapp.com/api/guilds/188630481301012481/widget.png?style=shield)](https://discord.gg/ppy)

Assets used by osu!.

## Requirements

This is a dependency of [osu!](https://github.com/ppy/osu) and intended to be used as a NuGet package only.

## Licence

The majority of content in this repository is licensed under [CC-BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/legalcode). Please see [the licence file](LICENCE.md) for more information. [tl;dr](https://tldrlegal.com/license/creative-commons-attribution-noncommercial-4.0-international-(cc-by-nc-4.0)) you can use it in a non-commercial manner.

Some fonts have separate licencing; please ensure to check their local licence files before distributing them.

Please note that this *does not cover* the usage of the "osu!" or "ppy" branding in any software, resources, advertising or promotion, as this is protected by trademark law. If you require clearance for the use of these terms, please [contact us](mailto:contact@ppy.sh).
